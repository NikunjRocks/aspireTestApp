import React from 'react';
import {View, Image} from 'react-native';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {appImages} from '../styles/appImages';

const Header = ({
  isShowBack = false,
  onBackPress = () => {},
}) => {
  const insets = useSafeAreaInsets();
  return (
    <View
      style={{
        width: '100%',
        height: 50,
        marginTop: insets.top,
        flexDirection: 'row',
        alignItems: 'center',
      }}>
      {isShowBack && (
        <TouchableOpacity onPress={onBackPress}>
          <Image
            source={appImages.back}
            style={{height: 25, width: 25, resizeMode: 'contain'}}
          />
        </TouchableOpacity>
      )}
      <View style={{flex: 1}}></View>
      <Image
        source={appImages.upLogo}
        style={{height: 30, width: 30, resizeMode: 'contain'}}
      />
    </View>
  );
};

export default Header;
