import { applyMiddleware, createStore } from 'redux';
import thunk from 'redux-thunk';
import { composeWithDevTools } from 'redux-devtools-extension';

import { createReducerManager } from './reducerManager';
import dashBoard from './dashBoard';

const initialReducers = {
  dashBoard,
};

export default function configureStore(preloadedState: { [x: string]: unknown; } | undefined) {
  const reducerManager = createReducerManager(initialReducers);

  const store = createStore(
    reducerManager.reduce,
    preloadedState,
    composeWithDevTools(applyMiddleware(thunk)),
  );

  store.reducerManager = reducerManager;

  return store;
}
