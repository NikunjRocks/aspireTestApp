import produce from 'immer';
import {appImages} from '../styles/appImages';

const SET_DEBIT_SETTINGS = 'SET_DEBIT_SETTINGS';

const initialState = {
  arrDebitSetting: [
    {
      image: appImages.topUp,
      title: 'Top-up account',
      detail: 'Deposit money to your account to use with card',
    },
    {
      image: appImages.weeklyLimit,
      title: 'Weekly spending limit',
      detail: 'You haven’t set any spending limit on card',
      isSelected: false,
    },
    {
      image: appImages.FreezCard,
      title: 'Freeze card',
      detail: 'Your debit card is currently active',
      isSelected: false,
    },
    {
      image: appImages.card,
      title: 'Get a new card',
      detail: 'This deactivates your current debit card',
    },
    {
      image: appImages.deactivateCard,
      title: 'Deactivated cards',
      detail: 'Your previously deactivated cards',
    },
  ],
};

// reducer
export default (state = initialState, action: {type: any; payload: any}) =>
  produce(state, (draft) => {
    switch (action.type) {
      case SET_DEBIT_SETTINGS:
        draft.arrDebitSetting = action.payload;
        break;
    }
  });

export const setArrDebitSetting = (arr = []) => ({
  type: SET_DEBIT_SETTINGS,
  payload: arr,
});
