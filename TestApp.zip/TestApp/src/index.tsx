import React from 'react';
import {View, StyleSheet} from 'react-native';
import {Provider} from 'react-redux';
import Navigator from './navigation';
import configureStore from './store/configureStore';

const store = configureStore();

export default function App() {
  return (
    <Provider store={store}>
      <View style={styles.container}>
        <Navigator />
      </View>
    </Provider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
