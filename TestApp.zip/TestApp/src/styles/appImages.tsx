export const appImages = {
  upLogo: require('../assets/images/upLogo.png'),
  back: require('../assets/images/back.png'),
  aspireLogo: require('../assets/images/aspireLogo.png'),
  visaLogo: require('../assets/images/visaLogo.png'),
  enableEye: require('../assets/images/enableEye.png'),
  disableEye: require('../assets/images/disableEye.png'),
  topUp: require('../assets/images/topUp.png'),
  weeklyLimit: require('../assets/images/weeklyLimit.png'),
  FreezCard: require('../assets/images/FreezCard.png'),
  meterIcon: require('../assets/images/meterIcon.png'),
  card: require('../assets/images/card.png'),
  deactivateCard: require('../assets/images/deactivateCard.png'),
};
