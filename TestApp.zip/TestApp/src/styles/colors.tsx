export const DARK_BLUE = '#0C365A';
export const LIGHT_GREEN = '#01D167';
export const GRAY = '#EEEEEE';
export const BLUE_TEXT = '#25345F';
export const GRAY_TEXT = '#22222266';
export const WHITE = '#FFFFFF';
